<?php $__env->startSection('head'); ?>
<style>
    iframe {
        width: 100%;
    }

    .mx-auto {
        margin-right: auto !important;
        margin-left: auto !important;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Pindah
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($data) <= 0): ?>

<div class="box">
    <div class="box-header">Form Alamat Pindah</div>
    <div class="box-body">
        <form action="" method="get">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6">
                    <label for="no_kk">Desa/Kelurahan</label>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" placeholder="Masukan Desa/Kelurahan" name="desa_kelurahan">
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="no_kk">RT</label>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" placeholder="Masukan RT" name="rt">
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="no_kk">Kecamatan</label>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" placeholder="Masukan Kecamatan" name="kecamatan">
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="no_kk">Kabupaten/Kota</label>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" placeholder="Masukan Kabupaten/Kota" name="kabupaten_kota">
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="no_kk">Provinsi</label>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" placeholder="Masukan Provinsi" name="provinsi">
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="no_kk">Tanggal Pindah</label>
                    <div class="form-group has-feedback">
                        <input type="date" class="form-control" name="tanggal">
                    </div>
                </div>
                <div class="col-md-12">
                    <label for="no_kk">Alasan Pindah</label>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" placeholder="Masukan Alasan Pindah" name="alasan_pindah">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group has-feedback">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Selanjutnya</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php if(count($data) > 0): ?>

<div style="background-color: whitesmoke; padding-top:25px; padding-bottom:25px">
    <div class="row">
        <div class="col-md-12 text-center">
            <iframe src="<?php echo e(route('sk.pindah.pdf.view', $data)); ?>" frameborder="0" height="800"></iframe>
            
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\administrasidesabanda\resources\views/dashboard/surat-keterangan/pindah/index.blade.php ENDPATH**/ ?>