<?php $__env->startSection('head'); ?>
<style>
    iframe{
        width: 100%;
    }
    .mx-auto {
        margin-right: auto !important;
        margin-left: auto !important;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Belum Nikah
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div style="background-color: whitesmoke; padding-top:25px; padding-bottom:25px">
    <div class="row">
        <div class="col-md-12 text-center">
            <iframe src="<?php echo e(route('sk.belum-nikah.pdf.view')); ?>" frameborder="0" height="800"></iframe>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\administrasidesabanda\resources\views/dashboard/surat-keterangan/belum-nikah/index.blade.php ENDPATH**/ ?>