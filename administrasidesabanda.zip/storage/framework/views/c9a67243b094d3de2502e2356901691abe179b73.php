<?php $__env->startSection('title'); ?>
Penduduk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Detail Penduduk</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <?php if($warga->confirmed_at == null): ?>
        <form action="<?php echo e(route('penduduk.confirm', $warga->id)); ?>" method="post" class="text-right">
            <?php echo csrf_field(); ?>
            <button class="btn btn-sm bg-maroon" type="submit" name="confirm" value="tolak" onclick="return confirm('Yakin ingin menolak data?')">Tolak</button>
            <button class="btn btn-sm bg-green" type="submit" name="confirm" value="terima" onclick="return confirm('Yakin ingin menerima data?')">Terima</button>
        </form>
        <?php endif; ?>

        <div class="row" id="data">
            <div class="col-md-6">
                <label for="no_kk">No. KK</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan No. KK" name="no_kk" value="<?php echo e($warga->no_kk); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <label for="nik">NIK</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan NIK" name="nik" value="<?php echo e($warga->nik); ?>">
                </div>
            </div>
            <div class="col-md-12">
                <label for="nama">Nama</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan Nama" name="nama" value="<?php echo e($warga->nama); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <label for="tempat_lahir">Tempat Lahir</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan Tempat Lahir" name="tempat_lahir" value="<?php echo e($warga->tempat_lahir); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <div class="form-group has-feedback">
                    <input type="date" class="form-control" placeholder="" name="tanggal_lahir" value="<?php echo e($warga->tanggal_lahir); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <label for="jenis_kelamin">Jenis Kelamin</label>
                <div class="form-group has-feedback">
                    <select class="form-control" name="jenis_kelamin">
                        <?php $__currentLoopData = config('constant.jenis_kelamin'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php echo e($item == $warga->jenis_kelamin ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <label for="status_hubungan_keluarga">Status Hubungan Keluarga</label>
                <div class="form-group has-feedback">
                    <select class="form-control" name="status_hubungan_keluarga">
                        <?php $__currentLoopData = config('constant.status_hubungan_keluarga'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php echo e($item == $warga->status_hubungan_keluarga ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <label for="agama">Agama</label>
                <div class="form-group has-feedback">
                    <select class="form-control" name="agama">
                        <?php $__currentLoopData = config('constant.agama'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php echo e($item == $warga->agama ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <label for="pendidikan">Pendidkan</label>
                <div class="form-group has-feedback">
                    <select class="form-control" name="pendidikan">
                        <?php $__currentLoopData = config('constant.pendidikan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php echo e($item == $warga->pendidikan ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-12">
                <label for="pekerjaan">Pekerjaan</label>
                <div class="form-group has-feedback">
                    <select class="form-control" name="pekerjaan">
                        <?php $__currentLoopData = config('constant.pekerjaan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php echo e($item == $warga->pekerjaan ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <label for="nama_ayah">Nama Ayah</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan Nama Ayah" name="nama_ayah" value="<?php echo e($warga->nama_ayah); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <label for="nama_ibu">Nama Ibu</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan Nama Ibu" name="nama_ibu" value="<?php echo e($warga->nama_ibu); ?>">
                </div>
            </div>
            <div class="col-md-8">
                <label for="alamat">Alamat</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan Alamat" name="alamat" value="<?php echo e($warga->alamat); ?>">
                </div>
            </div>
            <div class="col-md-2">
                <label for="rw">RW</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan RW" name="rw" value="<?php echo e($warga->rw); ?>">
                </div>
            </div>
            <div class="col-md-2">
                <label for="rt">RT</label>
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="Masukan RT" name="rt" value="<?php echo e($warga->rt); ?>">
                </div>
            </div>
            
            <!-- /.col -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('#data input').attr('disabled', true);
    $('#data select').attr('disabled', true);

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\administrasidesabanda\resources\views/dashboard/penduduk/show.blade.php ENDPATH**/ ?>