<?php $__env->startSection('head'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Penduduk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Data Penduduk</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">

        <div class="card">
            <div class="card-body">
                <form action="" method="get">
                    <div class="row">
                        <div class="form-group col-md-3 has-feedback">
                            <select type="text" class="form-control" name="rt">
                                <option value="0" <?php echo e(request()->query('rt') == 0 ? 'selected' : ''); ?>>Semua RT</option>
                                <?php $__currentLoopData = $rt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e(request()->query('rt') == $item->id ? 'selected' : ''); ?>><?php echo e($item->rt); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3 has-feedback">
                            <button type="submit" name="filter" value="filter" class="btn btn-success">Filter</button>
                            <button type="submit" name="cetak" value="cetak" class="btn btn-danger"> <i class="fa fa-file"></i> Cetak</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. KK</th>
                    <th>NIK</th>
                    <th>Nama</th>
                    <th>TTL</th>
                    <th>Jenis Kelamin</th>
                    <th>RT</th>
                    <th>Dikonfirmasi Pada</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $penduduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($item->no_kk); ?></td>
                    <td><?php echo e($item->nik); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->tempat_lahir); ?>, <?php echo e($item->tanggal_lahir); ?></td>
                    <td><?php echo e($item->jenis_kelamin); ?></td>
                    <td><?php echo e($item->rt->rt); ?></td>
                    <?php if($item->confirmed_at != null): ?>
                    <td><?php echo e($item->confirmed_at); ?></td>
                    <?php else: ?>
                    <td> <span class="badge bg-yellow">Belum Terkonfirmasi</span> </td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo e(route('penduduk.show', $item->id)); ?>" class="btn btn-sm bg-green">Lihat</a>
                        <form action="<?php echo e(route('penduduk.delete', $item->id)); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm bg-red" onclick="return confirm('Yakin ingin menghapus data?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('assets')); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
    $(function() {
        $('#example1').DataTable()
        $('#example2').DataTable({
            'paging': true
            , 'lengthChange': false
            , 'searching': false
            , 'ordering': true
            , 'info': true
            , 'autoWidth': false
        })
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\administrasidesabanda\resources\views/dashboard/penduduk/index.blade.php ENDPATH**/ ?>