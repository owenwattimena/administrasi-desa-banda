<?php $__env->startSection('head'); ?>
<style>
    iframe{
        width: 100%;
    }
    .mx-auto {
        margin-right: auto !important;
        margin-left: auto !important;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Izin Usaha
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(auth()->user()->role == 'admin'): ?>

<div class="box">
    <div class="box-header">Pengaturan</div>
    <div class="box-body">
        <form action="<?php echo e(route('pengaturan.save')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12">
                    <label for="no_kk">Nama Pejabat Negeri</label>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" placeholder="Masukan Nama Pejabat Negeri" name="nama_pejabat_negeri" value="<?php echo e($pengaturan->nama_pejabat_negeri ?? ''); ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <label for="no_kk">NIP Pejabat Negeri</label>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" placeholder="Masukan NIP Pejabat Negeri" name="nip_pejabat_negeri" value="<?php echo e($pengaturan->nip_pejabat_negeri ?? ''); ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group has-feedback">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Simpan</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\administrasidesabanda\resources\views/dashboard/pengaturan/index.blade.php ENDPATH**/ ?>