<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php if(auth()->user()->role == 'admin'): ?>

    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-aqua">
            <div class="inner">
                <h3><?php echo e($total_warga); ?></h3>

                <p>Total Warga</p>
            </div>
            <div class="icon">
                <i class="fa fa-users"></i>
            </div>
            
        </div>
    </div>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-orange">
            <div class="inner">
                <h3><?php echo e($total_perempuan); ?></h3>

                <p>Total Perempuan</p>
            </div>
            <div class="icon">
                <i class="fa fa-female"></i>
            </div>
            
        </div>
    </div>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-yellow">
            <div class="inner">
                <h3><?php echo e($total_laki); ?></h3>

                <p>Total Laki-laki</p>
            </div>
            <div class="icon">
                <i class="fa fa-male"></i>
            </div>
            
        </div>
    </div>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-red">
            <div class="inner">
                <h3><?php echo e($total_kk); ?></h3>

                <p>Total KK</p>
            </div>
            <div class="icon">
                <i class="fa fa-address-card"></i>
            </div>
            
        </div>
    </div>
    <?php else: ?>
    <div class="col-md-12">
        <div class="p-5 callout callout-info">
            <h4>Hi, <?php echo e(auth()->user()->nama); ?>!</h4>
            <p>Selamat datang!</p>
        </div>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\administrasidesabanda\resources\views/dashboard/home/index.blade.php ENDPATH**/ ?>